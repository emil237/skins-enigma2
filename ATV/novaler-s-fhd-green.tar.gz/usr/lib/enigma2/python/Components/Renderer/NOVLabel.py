# Embedded file name: /usr/lib/enigma2/python/Components/Renderer/FixedLabel.py
from Renderer import Renderer
from enigma import eLabel

class NOVLabel(Renderer):
    GUI_WIDGET = eLabel